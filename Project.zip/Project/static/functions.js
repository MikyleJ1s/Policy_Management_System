
const update_user = () => {
    
    try{
        
        alert("Updated the details successfully");
        alert("hello there");
        //myconn = mysql.connector.connect(host="localhost", user="root", passwd="Mikyle123", database="policy_management_system")
        alert("all good")
        //cur = myconn.cursor()
        //cur.execute("update user_table set user_name = 'Bob' where user_identifier = '1'")
    }             
    catch{
        //myconn.rollback()
    }
    //myconn.close()
}

